Below is the design of the dropdown button element

![N|Solid](https://i.ibb.co/sQQQ0V4/Screenshot-2021-11-22-at-11-55-24-PM.png)


[Click Here to view Adobe XD Design Page (on page 4)] 


![N|Solid](https://i.ibb.co/MSdtb6v/Screenshot-2021-11-23-at-12-01-11-AM.png)



####You can use the color-codes/dimensions from the xd link ( in “View Specs”) section



##After you finish making changes, upload the project in your personal github/gitlab account and make visibility public, and paste the project link in "Final project git url" input below


Important Note

- You need to use your knowledge of HTML/CSS to make such component.
- No external css library or javascript framework/library should be used.
- All the states e.g. focus, hover, active, disabled etc. should be covered.


[Click Here to view Adobe XD Design Page (on page 4)]: <https://xd.adobe.com/view/e49e5003-156c-40bb-a488-e1867aa9a759-b1cd/screen/d3f129fe-26a0-4175-af20-92e8737ae8c1/specs/>
